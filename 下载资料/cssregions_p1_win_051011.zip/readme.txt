﻿Adobe CSS Regions prototype, Copyright (c) 2011 Adobe Systems Incorporated 

About
-----

CSS Regions bring new properties to CSS (Cascading Style Sheets) that provide:
    * text containers with custom shapes.
    * exclusion shapes which text will wrap around.
    * text that flows from one area into another.
We have put together a set of demos for you. They showcase some of the concepts we proposed to the 
W3C with CSS Regions: content threads, content shapes and text exclusions.
The samples presented here require a mini-browser using a specially modified version of WebKit. 
This experimental version will allow you to experiment with the samples, and are a way for us to 
explore the implementation options for these features. Please see the "Usage instructions" section 
below for instructions on how to run this browser.
You'll find basic samples that demonstrate individual CSS properties, as well as more complex ideas 
that highlight how they work together. 


Usage instructions
------------------

Double-click on WinLauncher.exe that can be found in the bin\ folder of this package


Supported platforms 
-------------------

Windows XP (smoke-tested on Professional) - see also "Troubleshooting" section
Windows 7 (smoke-tested Professional)


Changelog
---------

v0.1
	This is the first public build. 
	For a complete description of the features supported, check the landing page of the browser 
	distributed with this package - see "Usage instructions" section below.


Release identification
----------------------

The version of this package is 0.1. 
The version can be identified using navigator.useragent property, which contains "AdobeCSSRegionsPrototype/0.1"
This package is distributed via http://www.adobe.com/go/cssregions


Troubleshooting
---------------

Libraries needed for this package (and included with it) have been compiled for Windows using 
Visual C++ 2005, thus its SP1 Redistributable Package (x86 version, vcredist_x86.exe) is needed.
	See http://www.microsoft.com/downloads/en/details.aspx?familyid=766a6af7-ec73-40ff-b072-9112bab119c2.


Copyright information
---------------------

This package is provided under the MIT License specified in LICENSING.txt file that accompanies this package.

Important note: 
This release uses several copyrighted libraries. See section "Libraries used by this release" for details 
on permissions and warranty for these libraries.
Majority of these libraries have not been modified by Adobe for this release. 
The only library that has been modified is the WebKit library with the intention to accommodate 
CSSRegions features this release aims to demonstrate.
Source code of the modified WebKit is available at http://sourceforge.net/adobe/adobe-webkit/ and 
files modified have their header properly marked.


Libraries used by this release
------------------------------

This release uses the following libraries, either statically or dynamically linked, as mentioned below.
Note that this package uses also other libraries available from the operating system (e.g. gdi32.dll) and 
from Visual C++ 2005 SP1 redistributable package.
All libraries linked dynamically are included in the release package.
Details on permissions and warranty and a copy of each license are distributed with this release in 
a file called LICENSING.txt.

1. WebKit version 82111 
This library has been modified by Adobe to add CSSRegions features and modified source code is made 
available by Adobe - see "Copyright information" section.

2. Cairo graphics library Win32 version 1.8.8

3. Independent JPEG Group's JPEG software version 6b (libjpeg)

4. libpng version 1.2.8

5. pixman version 0.11.6

6. cURL version 7.21.1

7. ICU version 4.0.0.0 (icudt40, icuin40 and icuuc40)

8. Libexslt version 0.8.15

9. Libxslt version 1.1.26

10. Libxml2 version 2.7.6

11. OpenCFLite version 476.17.2

12. PThreadVC2 version 2.8.0.0

13. ZLib version 1.2.3


Acknowledgements
----------------

We would like to thank following people and organizations that contributed to the creation and/or 
maintenance of abovementioned libraries used by this release:
	the Independent JPEG Group for allowing us to use libjpeg library
	Glenn Randers-Pehrson for allowing us to use libpng library
	Jean-loup Gailly and Mark Adler for allowing us to use zlib library

End of document