<?php define('CLICKHEAT_VERSION', '1.9-revD'); ?>
