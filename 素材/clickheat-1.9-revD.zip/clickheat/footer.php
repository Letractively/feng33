<?php
/**
 * Clickheat : Fichier de pied de page / Footer file
 * 
 * @author Yvan Taviaud / Labsmedia
 * @since 02/04/2007
**/

/** Direct call forbidden */
if (!defined('CLICKHEAT_LANGUAGE'))
{
	exit;
}

?>
</body>
</html>